# Nunchucks Syntax (VS Code)

Local VS Code extension for Nunchucks template highlighting.

## Install Locally

1. Open VS Code.
2. Run command: `Extensions: Install from VSIX...` (if you pack it) or use:
   - `Developer: Install Extension from Location...`
3. Select this folder: `vscode-nunchucks`.

## Language Id

- `nunchucks-template`

## File Extensions

- `.njk`
- `.nunchucks`
